//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteNetwork.java                  ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================

import java.util.*;
import ReteObjects.*;
import java.io.*;
//import WorkingMemory.*;
//import WMServer.*;
import MemoryServer.*;

import org.omg.CORBA.Any;
import org.omg.CORBA.ORB;
import org.omg.CORBA.OBJ_ADAPTER;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextHelper;
import org.omg.CosNaming.NameComponent;
import org.omg.PortableServer.POA;


//import org.omg.CORBA.ORB;
//import org.omg.CORBA.Object;
//import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CORBA.Policy;
import org.omg.PortableServer.Servant;
import org.omg.PortableServer.*;
//import org.omg.PortableServer.POA;


public class ReteNetwork
{
  private ArrayList ListOfObjects = new ArrayList();
	private ArrayList ListOfNames = new ArrayList();

  private ReteExecute executions;
  private int time_stamp = 0;
  private WMGetSetObject wmserverinterface = null;
  private org.omg.CORBA.Any anyholder;

  private Expert expert = null;
  int crm = 0;
  public boolean stop = false;



//----------------- Rule nodes -----------------
		ReteNodeFinal Rule1_ProblemDeadBattery1 = new ReteNodeFinal(-7, 0);
		ReteNodeFinal Rule2_ProblemDeadBattery2 = new ReteNodeFinal(-10, 0);
		ReteNodeFinal Rule3_ProblemBadIgnition = new ReteNodeFinal(-1, 0);
		ReteNodeFinal Rule4_ProblemFuelSystem = new ReteNodeFinal(-2, 0);
		ReteNodeFinal Rule5_ProblemNoGas = new ReteNodeFinal(-8, 0);
		ReteNodeFinal Rule6_ProblemBadStarter = new ReteNodeFinal(-9, 0);
		ReteNodeFinal Rule7_ProblemFloodedEng = new ReteNodeFinal(-3, 0);
		ReteNodeFinal Rule8_ProblemFuelIgn = new ReteNodeFinal(-4, 0);
		ReteNodeFinal Rule9_ProblemStartSystem = new ReteNodeFinal(-5, 0);
		ReteNodeFinal Rule10_Start1 = new ReteNodeFinal(-12, 0);
		ReteNodeFinal Rule11_Start = new ReteNodeFinal(-6, 0);
		ReteNodeFinal Rule12_FinalDiagnostic = new ReteNodeFinal(-11, 0);

//----------------- Condition nodes -----------------
		ReteNodeCondition Condition1 = new ReteNodeCondition();
		ReteNodeCondition Condition2 = new ReteNodeCondition();
		ReteNodeCondition Condition3 = new ReteNodeCondition();
		ReteNodeCondition Condition4 = new ReteNodeCondition();
		ReteNodeCondition Condition5 = new ReteNodeCondition();
		ReteNodeCondition Condition6 = new ReteNodeCondition();
		ReteNodeCondition Condition7 = new ReteNodeCondition();
		ReteNodeCondition Condition8 = new ReteNodeCondition();
		ReteNodeCondition Condition9 = new ReteNodeCondition();
		ReteNodeCondition Condition10 = new ReteNodeCondition();
		ReteNodeCondition Condition11 = new ReteNodeCondition();
		ReteNodeCondition Condition12 = new ReteNodeCondition();
		ReteNodeCondition Condition13 = new ReteNodeCondition();
		ReteNodeCondition Condition14 = new ReteNodeCondition();
		ReteNodeCondition Condition15 = new ReteNodeCondition();
		ReteNodeCondition Condition16 = new ReteNodeCondition();
		ReteNodeCondition Condition17 = new ReteNodeCondition();
		ReteNodeCondition Condition18 = new ReteNodeCondition();
		ReteNodeCondition Condition19 = new ReteNodeCondition();
		ReteNodeCondition Condition20 = new ReteNodeCondition();
		ReteNodeCondition Condition21 = new ReteNodeCondition();

//----------------- Logic nodes -----------------
		ReteNodeAND And1 = new ReteNodeAND();
		ReteNodeAND And2 = new ReteNodeAND();
		ReteNodeAND And3 = new ReteNodeAND();
		ReteNodeAND And4 = new ReteNodeAND();
		ReteNodeAND And5 = new ReteNodeAND();
		ReteNodeAND And6 = new ReteNodeAND();
		ReteNodeAND And7 = new ReteNodeAND();
		ReteNodeAND And8 = new ReteNodeAND();
		ReteNodeAND And9 = new ReteNodeAND();
		ReteNodeAND And10 = new ReteNodeAND();
		ReteNodeAND And11 = new ReteNodeAND();
		ReteNodeAND And12 = new ReteNodeAND();
		ReteNodeAND And13 = new ReteNodeAND();
		ReteNodeAND And14 = new ReteNodeAND();
		ReteNodeAND And15 = new ReteNodeAND();
		ReteNodeAND And16 = new ReteNodeAND();
		ReteNodeAND And17 = new ReteNodeAND();
		ReteNodeAND And18 = new ReteNodeAND();
		ReteNodeAND And19 = new ReteNodeAND();
		ReteNodeAND And20 = new ReteNodeAND();
		ReteNodeAND And21 = new ReteNodeAND();
		ReteNodeAND And22 = new ReteNodeAND();
		ReteNodeAND And23 = new ReteNodeAND();
		ReteNodeAND And24 = new ReteNodeAND();
		ReteNodeAND And25 = new ReteNodeAND();
		ReteNodeAND And26 = new ReteNodeAND();

//	int timer = 0;
	public static void main(String args[]) throws NoSuchFieldException, IllegalAccessException, IOException, org.omg.CORBA.TypeCodePackage.BadKind
	{
		ReteNetwork rn= new ReteNetwork();
    
		rn.CreateNetwork();
    rn.ConnectMemory(args);
    rn.StartInferencing();
	}

  public static ReteNetwork WinMain(Expert expert, WMGetSetObject memimpl, Any any) throws NoSuchFieldException, IllegalAccessException, IOException, org.omg.CORBA.TypeCodePackage.BadKind
	{
		ReteNetwork rn= new ReteNetwork();
    rn.expert = expert;
    rn.wmserverinterface = memimpl;
    rn.crm = expert.crm;

    rn.CreateNetwork();
	  rn.anyholder = any;
    rn.StartInferencing();
    return rn;
	}

  public void SetAllTransparent()
	{

		Condition1.SetTransparent();
		Condition2.SetTransparent();
		Condition3.SetTransparent();
		Condition4.SetTransparent();
		Condition5.SetTransparent();
		Condition6.SetTransparent();
		Condition7.SetTransparent();
		Condition8.SetTransparent();
		Condition9.SetTransparent();
		Condition10.SetTransparent();
		Condition11.SetTransparent();
		Condition12.SetTransparent();
		Condition13.SetTransparent();
		Condition14.SetTransparent();
		Condition15.SetTransparent();
		Condition16.SetTransparent();
		Condition17.SetTransparent();
		Condition18.SetTransparent();
		Condition19.SetTransparent();
		Condition20.SetTransparent();
		Condition21.SetTransparent();
	}
	
  public void ConnectMemory(String args[]) throws org.omg.CORBA.TypeCodePackage.BadKind
  {
    try
    {
      // create and initialize the ORB
      ORB orb = ORB.init(args, null);

      anyholder = orb.create_any();

      // get the root naming context
      org.omg.CORBA.Object objRef = 
        orb.resolve_initial_references("NameService");

      // Use NamingContextExt instead of NamingContext. This is 
      // part of the Interoperable Naming Service.  
      NamingContextExt ncRef = 
        NamingContextExtHelper.narrow(objRef);
 
      // resolve the Object Reference in Naming
      String name = "WMGetSetObject";
      wmserverinterface = WMGetSetObjectHelper.narrow(ncRef.resolve_str(name));

      org.omg.CORBA.StringHolder on = new org.omg.CORBA.StringHolder();
		  on.value = "... --- ...";

      try{wmserverinterface.WMGetItem(0, on);}
      catch(Throwable e){wmserverinterface = null;}

//      System.out.println("ConnectMemory wmserverinterface= " + wmserverinterface);
/*
      ORB orb = ORB.init(args, null);
      org.omg.CORBA.Object obj = orb.string_to_object("corbaname::localhost:2900#AddServer");
      anyholder = orb.create_any();
      wmserverinterface = WMGetSetObjectHelper.narrow(obj);
*/
    } 
    catch ( Exception e ) 
    {
//       System.err.println( "Exception connecting to memory server..." + e );
//       e.printStackTrace( );
    }
  }

  public String TextList()
  {
    StringBuffer sb = new StringBuffer();
    sb.append("\tObjects list:\n");
    for(int i = 0; i < ListOfObjects.size(); i++) sb.append("\t\t" + ListOfObjects.get(i) + " : " + ListOfNames.get(i) + "\n");
    return sb.toString();
  }

// Returns 1, 2 or 3 if variable is of type 
// String, Integer or Double respectively; 0 otherwise.
	public static int TypeOfObject(Object x)
	{
		String xx = x.getClass().getName();
		if(xx.compareTo("java.lang.String")==0) return 1;
		if(xx.compareTo("java.lang.Integer")==0) return 2;
		if(xx.compareTo("java.lang.Double")==0) return 3;
		return 0;
	}
	public static int TypeOfObject(String x){return 1;}
	public static int TypeOfObject(Integer x){return 2;}
	public static int TypeOfObject(Double x){return 3;}
	public static int TypeOfObject(int x){return 2;}
	public static int TypeOfObject(double x){return 3;}

	public static String ReturnClass(String x){return x;}
	public static Double ReturnClass(double x){return new Double(x);}
	public static Integer ReturnClass(int x){return new Integer(x);}
	public static Double ReturnClass(Double x){return x;}
	public static Integer ReturnClass(Integer x){return x;}


	public boolean FeedNetwork(Object obj, int time_stamp)
	{
		ReteToken token;
		if(obj.getClass().getName().compareTo("ReteObjects.car")==0)
		{
//  car:problem:==:"unknown"  1:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).problem) == 1)
			{
				if(((car)obj).problem != null)
				if(((car)obj).problem.compareTo("unknown")==0)
					Condition1.InputCondition(token);
			}

//  car:init_problem:==:"starting_system"  2:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).init_problem) == 1)
			{
				if(((car)obj).init_problem != null)
				if(((car)obj).init_problem.compareTo("starting_system")==0)
					Condition2.InputCondition(token);
			}

//  car:headlights:==:"dim"  3:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).headlights) == 1)
			{
				if(((car)obj).headlights != null)
				if(((car)obj).headlights.compareTo("dim")==0)
					Condition3.InputCondition(token);
			}

//  car:headlights:==:"dead"  4:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).headlights) == 1)
			{
				if(((car)obj).headlights != null)
				if(((car)obj).headlights.compareTo("dead")==0)
					Condition4.InputCondition(token);
			}

//  car:init_problem:==:"fuel_or_ignition"  5:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).init_problem) == 1)
			{
				if(((car)obj).init_problem != null)
				if(((car)obj).init_problem.compareTo("fuel_or_ignition")==0)
					Condition5.InputCondition(token);
			}

//  car:headlights:==:"working"  6:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).headlights) == 1)
			{
				if(((car)obj).headlights != null)
				if(((car)obj).headlights.compareTo("working")==0)
					Condition6.InputCondition(token);
			}

//  car:spark_plug_spark:==:"none"  7:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).spark_plug_spark) == 1)
			{
				if(((car)obj).spark_plug_spark != null)
				if(((car)obj).spark_plug_spark.compareTo("none")==0)
					Condition7.InputCondition(token);
			}

//  car:Fuel_gauge_reading:==:"full"  8:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).Fuel_gauge_reading) == 1)
			{
				if(((car)obj).Fuel_gauge_reading != null)
				if(((car)obj).Fuel_gauge_reading.compareTo("full")==0)
					Condition8.InputCondition(token);
			}

//  car:carburetor_gas:==:"yes"  9:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).carburetor_gas) == 1)
			{
				if(((car)obj).carburetor_gas != null)
				if(((car)obj).carburetor_gas.compareTo("yes")==0)
					Condition9.InputCondition(token);
			}

//  car:Fuel_gauge_reading:==:"empty"  10:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).Fuel_gauge_reading) == 1)
			{
				if(((car)obj).Fuel_gauge_reading != null)
				if(((car)obj).Fuel_gauge_reading.compareTo("empty")==0)
					Condition10.InputCondition(token);
			}

//  car:spark_plug_spark:==:"exists"  11:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).spark_plug_spark) == 1)
			{
				if(((car)obj).spark_plug_spark != null)
				if(((car)obj).spark_plug_spark.compareTo("exists")==0)
					Condition11.InputCondition(token);
			}

//  car:init_problem:==:"unknown"  12:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).init_problem) == 1)
			{
				if(((car)obj).init_problem != null)
				if(((car)obj).init_problem.compareTo("unknown")==0)
					Condition12.InputCondition(token);
			}

//  car:ignition_key:==:"on"  13:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).ignition_key) == 1)
			{
				if(((car)obj).ignition_key != null)
				if(((car)obj).ignition_key.compareTo("on")==0)
					Condition13.InputCondition(token);
			}

//  car:engine_turning_over:==:"yes"  14:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).engine_turning_over) == 1)
			{
				if(((car)obj).engine_turning_over != null)
				if(((car)obj).engine_turning_over.compareTo("yes")==0)
					Condition14.InputCondition(token);
			}

//  car:engine_turning_over:==:"no"  15:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).engine_turning_over) == 1)
			{
				if(((car)obj).engine_turning_over != null)
				if(((car)obj).engine_turning_over.compareTo("no")==0)
					Condition15.InputCondition(token);
			}

//  car:vehicle_make:==: $10$mak   17:0:1:8
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			token.variable[0] = ReturnClass(((car)obj).vehicle_make);
			token.typeofvariable[0] = TypeOfObject(((car)obj).vehicle_make);
			Condition17.InputCondition(token);

//  car:ignition_key:!=:"on"  18:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).ignition_key) == 1)
			{
				if(((car)obj).ignition_key != null)
				if(((car)obj).ignition_key.compareTo("on")!=0)
					Condition18.InputCondition(token);
			}

//  car:problem:!=:"unknown"  20:0:0:4
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((car)obj).problem) == 1)
			{
				if(((car)obj).problem != null)
				if(((car)obj).problem.compareTo("unknown")!=0)
					Condition20.InputCondition(token);
			}

//  car:problem:==: $11$problem   21:0:3:8
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			token.variable[2] = ReturnClass(((car)obj).problem);
			token.typeofvariable[2] = TypeOfObject(((car)obj).problem);
			Condition21.InputCondition(token);

		}
		else if(obj.getClass().getName().compareTo("ReteObjects.COSMOS_START")==0)
		{
//  COSMOS_START:init_status:==:1  16:0:0:1
			token = new ReteToken();
			token.ClearToken();
			token.object[0] = obj;
			token.timestamps[0] = time_stamp;
			if(TypeOfObject(((COSMOS_START)obj).init_status) == 2 || TypeOfObject(((COSMOS_START)obj).init_status) == 3)
			{
				if(((COSMOS_START)obj).init_status == 1)
					Condition16.InputCondition(token);
			}

		}
		else if(obj.getClass().getName().compareTo("ReteObjects.mechanic")==0)
		{
//  mechanic:first_name:==: $10$name   19:1:2:8
			token = new ReteToken();
			token.ClearToken();
			token.object[1] = obj;
			token.timestamps[1] = time_stamp;
			token.variable[1] = ReturnClass(((mechanic)obj).first_name);
			token.typeofvariable[1] = TypeOfObject(((mechanic)obj).first_name);
			Condition19.InputCondition(token);

		}
		return false;
	}

	public void UnFeedNetwork(Object obj)
	{
    ReteConflictSet.RemoveTokensWithObsoleteObjects(obj);

		if(obj.getClass().getName().compareTo("ReteObjects.car")==0)
		{
			Condition1.RemoveObsoleteTokens(obj);
			Condition2.RemoveObsoleteTokens(obj);
			Condition3.RemoveObsoleteTokens(obj);
			Condition4.RemoveObsoleteTokens(obj);
			Condition5.RemoveObsoleteTokens(obj);
			Condition6.RemoveObsoleteTokens(obj);
			Condition7.RemoveObsoleteTokens(obj);
			Condition8.RemoveObsoleteTokens(obj);
			Condition9.RemoveObsoleteTokens(obj);
			Condition10.RemoveObsoleteTokens(obj);
			Condition11.RemoveObsoleteTokens(obj);
			Condition12.RemoveObsoleteTokens(obj);
			Condition13.RemoveObsoleteTokens(obj);
			Condition14.RemoveObsoleteTokens(obj);
			Condition15.RemoveObsoleteTokens(obj);
			Condition17.RemoveObsoleteTokens(obj);
			Condition18.RemoveObsoleteTokens(obj);
			Condition20.RemoveObsoleteTokens(obj);
			Condition21.RemoveObsoleteTokens(obj);
		}
		else if(obj.getClass().getName().compareTo("ReteObjects.COSMOS_START")==0)
		{
			Condition16.RemoveObsoleteTokens(obj);
		}
		else if(obj.getClass().getName().compareTo("ReteObjects.mechanic")==0)
		{
			Condition19.RemoveObsoleteTokens(obj);
		}
	}

	public int CreateNetwork()
	{


//----------------- Connections -----------------
		Rule1_ProblemDeadBattery1.SetInputNode( And2 );
		And2.SetOutputNode( Rule1_ProblemDeadBattery1 );
		Rule2_ProblemDeadBattery2.SetInputNode( And3 );
		And3.SetOutputNode( Rule2_ProblemDeadBattery2 );
		Rule3_ProblemBadIgnition.SetInputNode( And6 );
		And6.SetOutputNode( Rule3_ProblemBadIgnition );
		Rule4_ProblemFuelSystem.SetInputNode( And9 );
		And9.SetOutputNode( Rule4_ProblemFuelSystem );
		Rule5_ProblemNoGas.SetInputNode( And11 );
		And11.SetOutputNode( Rule5_ProblemNoGas );
		Rule6_ProblemBadStarter.SetInputNode( And13 );
		And13.SetOutputNode( Rule6_ProblemBadStarter );
		Rule7_ProblemFloodedEng.SetInputNode( And16 );
		And16.SetOutputNode( Rule7_ProblemFloodedEng );
		Rule8_ProblemFuelIgn.SetInputNode( And19 );
		And19.SetOutputNode( Rule8_ProblemFuelIgn );
		Rule9_ProblemStartSystem.SetInputNode( And22 );
		And22.SetOutputNode( Rule9_ProblemStartSystem );
		Rule10_Start1.SetInputNode( Condition16 );
		Condition16.SetOutputNode( Rule10_Start1 );
		Rule11_Start.SetInputNode( And25 );
		And25.SetOutputNode( Rule11_Start );
		Rule12_FinalDiagnostic.SetInputNode( And26 );
		And26.SetOutputNode( Rule12_FinalDiagnostic );

		And1.SetInputNode( Condition2 );
		Condition2.SetOutputNode( And1 );
		And1.SetInputNode( Condition3 );
		Condition3.SetOutputNode( And1 );
		And2.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And2 );
		And2.SetInputNode( And1 );
		And1.SetOutputNode( And2 );
		And3.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And3 );
		And3.SetInputNode( Condition4 );
		Condition4.SetOutputNode( And3 );
		And4.SetInputNode( Condition6 );
		Condition6.SetOutputNode( And4 );
		And4.SetInputNode( Condition7 );
		Condition7.SetOutputNode( And4 );
		And5.SetInputNode( Condition5 );
		Condition5.SetOutputNode( And5 );
		And5.SetInputNode( And4 );
		And4.SetOutputNode( And5 );
		And6.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And6 );
		And6.SetInputNode( And5 );
		And5.SetOutputNode( And6 );
		And7.SetInputNode( Condition8 );
		Condition8.SetOutputNode( And7 );
		And7.SetInputNode( Condition9 );
		Condition9.SetOutputNode( And7 );
		And8.SetInputNode( Condition5 );
		Condition5.SetOutputNode( And8 );
		And8.SetInputNode( And7 );
		And7.SetOutputNode( And8 );
		And9.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And9 );
		And9.SetInputNode( And8 );
		And8.SetOutputNode( And9 );
		And10.SetInputNode( Condition5 );
		Condition5.SetOutputNode( And10 );
		And10.SetInputNode( Condition10 );
		Condition10.SetOutputNode( And10 );
		And11.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And11 );
		And11.SetInputNode( And10 );
		And10.SetOutputNode( And11 );
		And12.SetInputNode( Condition2 );
		Condition2.SetOutputNode( And12 );
		And12.SetInputNode( Condition6 );
		Condition6.SetOutputNode( And12 );
		And13.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And13 );
		And13.SetInputNode( And12 );
		And12.SetOutputNode( And13 );
		And14.SetInputNode( Condition9 );
		Condition9.SetOutputNode( And14 );
		And14.SetInputNode( Condition11 );
		Condition11.SetOutputNode( And14 );
		And15.SetInputNode( Condition5 );
		Condition5.SetOutputNode( And15 );
		And15.SetInputNode( And14 );
		And14.SetOutputNode( And15 );
		And16.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And16 );
		And16.SetInputNode( And15 );
		And15.SetOutputNode( And16 );
		And17.SetInputNode( Condition13 );
		Condition13.SetOutputNode( And17 );
		And17.SetInputNode( Condition14 );
		Condition14.SetOutputNode( And17 );
		And18.SetInputNode( Condition12 );
		Condition12.SetOutputNode( And18 );
		And18.SetInputNode( And17 );
		And17.SetOutputNode( And18 );
		And19.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And19 );
		And19.SetInputNode( And18 );
		And18.SetOutputNode( And19 );
		And20.SetInputNode( Condition13 );
		Condition13.SetOutputNode( And20 );
		And20.SetInputNode( Condition15 );
		Condition15.SetOutputNode( And20 );
		And21.SetInputNode( Condition12 );
		Condition12.SetOutputNode( And21 );
		And21.SetInputNode( And20 );
		And20.SetOutputNode( And21 );
		And22.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And22 );
		And22.SetInputNode( And21 );
		And21.SetOutputNode( And22 );
		And23.SetInputNode( Condition17 );
		Condition17.SetOutputNode( And23 );
		And23.SetInputNode( Condition18 );
		Condition18.SetOutputNode( And23 );
		And24.SetInputNode( Condition1 );
		Condition1.SetOutputNode( And24 );
		And24.SetInputNode( And23 );
		And23.SetOutputNode( And24 );
		And25.SetInputNode( And24 );
		And24.SetOutputNode( And25 );
		And25.SetInputNode( Condition19 );
		Condition19.SetOutputNode( And25 );
		And26.SetInputNode( Condition20 );
		Condition20.SetOutputNode( And26 );
		And26.SetInputNode( Condition21 );
		Condition21.SetOutputNode( And26 );
		return 0;
	}

	public void BackwardChainingSeq(ReteExecute executions)throws NoSuchFieldException, IllegalAccessException, IOException, org.omg.CORBA.TypeCodePackage.BadKind
	{
			boolean empty = true;
			ArrayList frl;
			boolean[] fired_rules = new boolean[12];
			for(int i=11; i>=0; i--) fired_rules[i] = false;

			ReteConflictSet.BackwardMode(12);
//Fresh rule #[11]
//Rule #[11]
			Condition20.SetTransparent();
			Condition21.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
			}
			while(!empty);
//Rule #[0]
			Condition1.SetTransparent();
			Condition2.SetTransparent();
			Condition3.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[1]
			Condition4.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[2]
			Condition5.SetTransparent();
			Condition6.SetTransparent();
			Condition7.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-1);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[2] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[3]
			Condition8.SetTransparent();
			Condition9.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-2);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[3] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-1);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[2] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[4]
			Condition10.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-8);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[4] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-2);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[3] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-1);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[2] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[5]
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-9);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[5] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-8);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[4] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-2);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[3] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-1);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[2] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[6]
			Condition11.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-3);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[6] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-9);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[5] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-8);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[4] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-2);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[3] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-1);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[2] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[7]
			Condition12.SetTransparent();
			Condition13.SetTransparent();
			Condition14.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-4);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[7] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-3);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[6] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-9);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[5] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-8);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[4] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-2);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[3] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-1);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[2] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[8]
			Condition15.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-5);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[8] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-4);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[7] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-3);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[6] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-9);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[5] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-8);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[4] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-2);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[3] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-1);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[2] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[10]
			Condition17.SetTransparent();
			Condition18.SetTransparent();
			Condition19.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-6);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[10] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-5);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[8] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-4);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[7] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-3);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[6] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-9);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[5] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-8);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[4] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-2);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[3] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-1);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[2] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Rule #[9]
			Condition16.SetTransparent();
			do
			{
				empty = true;
				frl = ReteConflictSet.GetFiredOfMerit(-11);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) return;
				frl = ReteConflictSet.GetFiredOfMerit(-6);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[10] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-12);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[9] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-5);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[8] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-4);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[7] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-3);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[6] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-9);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[5] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-8);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[4] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-2);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[3] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-1);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[2] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-10);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[1] = true; empty = false;}
				frl = ReteConflictSet.GetFiredOfMerit(-7);
				for(int i = 0; i<frl.size(); i++)
					executions.ExecuteRule((ReteToken)frl.get(i));
				if(frl.size()>0) {fired_rules[0] = true; empty = false;}
			}
			while(!empty);
//Fresh rule #[10]
//Fresh rule #[9]
//Fresh rule #[8]
//Fresh rule #[7]
//Fresh rule #[6]
//Fresh rule #[5]
//Fresh rule #[4]
//Fresh rule #[3]
//Fresh rule #[2]
//Fresh rule #[1]
//Fresh rule #[0]
	}

	public void StartInferencing() throws NoSuchFieldException, IllegalAccessException, IOException, org.omg.CORBA.TypeCodePackage.BadKind
  {
    ReteToken token;
    executions = new ReteExecute(this, expert); 

		if(crm == 3) 
		{
		COSMOS_START __starter = new COSMOS_START();
		__starter.init_status = 1;
		MemSetObject(__starter, "__starter");
			BackwardChainingSeq(executions);
		}
		else
		{
			SetAllTransparent();
      ReteConflictSet.ForwardMode();
		COSMOS_START __starter = new COSMOS_START();
		__starter.init_status = 1;
		MemSetObject(__starter, "__starter");
			do
			{
//				if(wmserverinterface!=null)	LoadObjectsFromWM();
				
				token = ReteConflictSet.GetFiredToken(crm);
				if(token != null)
				{
					ReteConflictSet.RemoveTokensFromFiredRule(token);
					executions.ExecuteRule(token);
					token = null;
				}
				else if(wmserverinterface!=null) LoadObjectsFromWM(true);
			}
	//    while(true);
	//    while((token != null) && (!stop));
			while(!stop);
		}
  }

  public void MemSetObject(Object obj, String name) 
  throws org.omg.CORBA.TypeCodePackage.BadKind, java.lang.IllegalAccessException
	{
    if(wmserverinterface==null)
    {
      time_stamp ++;
      if(name == null && obj != null)
      {
        UnFeedNetwork(obj);
        FeedNetwork(obj, time_stamp);
        return;
		  }
      
      int i = ListOfNames.indexOf(name);
		  if(i<0)
		  {
			  ListOfObjects.add(obj);
			  ListOfNames.add(name);
        FeedNetwork(obj, time_stamp);
		  }
		  else 
		  {
        if(obj == null)
        {
          Object oo = ListOfObjects.get(i);
          if(oo != null)
          {
            UnFeedNetwork(oo);
            //ReteConflictSet.RemoveTokensWithObsoleteObjects(oo);
            ListOfObjects.set(i, null);
          }
        }
        else
        {
          Object oo = ListOfObjects.get(i);
          UnFeedNetwork(oo);
          //ReteConflictSet.RemoveTokensWithObsoleteObjects(oo);
	  		  ListOfObjects.set(i, obj);
          FeedNetwork(obj, time_stamp);
        }
		  }
      //for( i = 0; i < ListOfNames.size(); i++) System.out.println("***+" + ListOfObjects.get(i) + " : " + ListOfNames.get(i));
    }
    else
    {
      if(name == null)
      {
        if(obj == null) return;
        int i = ListOfObjects.indexOf(obj);
  		  if(i<0) return;
  		  name = (String)ListOfNames.get(i);
      }

      if(obj == null)
      {
        wmserverinterface.WMDeleteObject(name);
				LoadObjectsFromWM(true);
      }
      else
      {
          Class objclass = obj.getClass();
          String classname = objclass.getName();
// Setting up null strings in object        
          java.lang.reflect.Field[] fields = objclass.getFields();
          for(int f = 0; f < fields.length; f++)
          {
            if(fields[f].getType() == classname.getClass())
              if(fields[f].get(obj) == null) fields[f].set(obj, "");
          }

//      (else) if(obj.getClass().getName().compareTo("ReteObjects.classname")==0) RzeczHelper.insert(anyholder, (classname)obj);

        boolean set = true;
		if(classname.compareTo("ReteObjects.car")==0) carHelper.insert(anyholder, (car)obj);
				else if(classname.compareTo("ReteObjects.COSMOS_START")==0) COSMOS_STARTHelper.insert(anyholder, (COSMOS_START)obj);
				else if(classname.compareTo("ReteObjects.mechanic")==0) mechanicHelper.insert(anyholder, (mechanic)obj);
		        else set = false;
        if(set)
				{
					wmserverinterface.WMSetObject(anyholder, name);
					LoadObjectsFromWM(true);
				}
      }
    }
  }
/*
  public Object MemGetObject(String name)
	{
		int i = ListOfNames.indexOf(name);
		if(i>=0) return ListOfObjects.get(i);
    else return null;
	}
*/


  public void LoadObjectsFromWM(boolean wait) throws org.omg.CORBA.TypeCodePackage.BadKind
  {
//    if(wmserverinterface == null) return;
//    expert.Print("+");
		if(wait) wmserverinterface.WMWaitForChange(time_stamp);

		org.omg.CORBA.IntHolder ti = new org.omg.CORBA.IntHolder();
			ti.value = 0;
		org.omg.CORBA.StringHolder on = new org.omg.CORBA.StringHolder();
 			on.value = "";
		org.omg.CORBA.AnyHolder ah = new org.omg.CORBA.AnyHolder();

		try
		{
      int tmax = -1;
      do
      {
        Object obj = null;

/*
        do{
          wmserverinterface.WMGetObject(time_stamp, ti, on, ah);
          if(stop) return;
        }while(time_stamp>=ti.value);
*/

        wmserverinterface.WMGetObject(time_stamp, ti, on, ah);

        if(ti.value<0) {stop = true; return;}

        if(tmax < 0) tmax = ti.value;

        if(ah.value == null || ah.value.type().kind() == org.omg.CORBA.TCKind.tk_null)
        {
          if(on.value != null)
          {
            int i = ListOfNames.indexOf(on.value);
		        if(i>=0)
            {
              UnFeedNetwork(ListOfObjects.get(i));
              ListOfObjects.set(i, null);
            }
          }
        }
        else
        {

		if(ah.value.type().name().compareTo("car")==0) obj = carHelper.extract(ah.value);
				else if(ah.value.type().name().compareTo("COSMOS_START")==0) obj = COSMOS_STARTHelper.extract(ah.value);
				else if(ah.value.type().name().compareTo("mechanic")==0) obj = mechanicHelper.extract(ah.value);
		
          if(on.value != null)
          {
            int i = ListOfNames.indexOf(on.value);
		        if(i>=0)
            {
              Object oo = ListOfObjects.get(i);
              if(oo != null) UnFeedNetwork(oo);
              ListOfObjects.set(i, obj);
            }
            else
            {
		  	      ListOfObjects.add(obj);
    		      ListOfNames.add(on.value);
            }
            FeedNetwork(obj, time_stamp+1);
          }
        }
		    time_stamp++;
				if(ti.value < tmax) break;
      }while(time_stamp < tmax);
    }
		catch(Throwable e){}
    Thread.yield();
  }
}

