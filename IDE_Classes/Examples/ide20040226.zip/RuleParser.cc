##SaveTo ReteNetwork.txt
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ParsingResults                    ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================
##WriteParsingResults

##SaveTo ReteNode.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteNode.java                     ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================

import java.util.*;
//==============================================================================
// ReteL node implementation. Interface for other nodes.
public abstract class ReteNode
{
// INTERFACE FUNCTONS:
// Function called by one of two input nodes when token is being sent
	public abstract void InputChange(Object calling_node, ReteToken input);
// Function returns no. of tokens on its output
	public abstract int GetToken();
// Function returns token of index
	public abstract ReteToken GetToken(int index);
// Function removes obsolete tokens, which contain info related to modified object
	public abstract void RemoveObsoleteTokens(Object modified_object);

//------------------------------------------------------------------------------
	ReteNode()
	{
		input_node0 = null;
		input_node1 = null;
		output_node = new ArrayList();
		output_tokens = new ArrayList();
	}

//------------------------------------------------------------------------------
	public void SetInputNode(Object calling_node)
	{
		if(input_node0 == null) input_node0 = calling_node;
		else if((input_node0 != calling_node) && input_node1 == null)
			input_node1 = calling_node;
//		else if((input_node0 != calling_node) && (input_node1 != calling_node))
//			System.out.println(":-( Two-input nodes allowed only!!!");
//		else System.out.println(":-( Input node already set!!!");
	}

//------------------------------------------------------------------------------
	public void SetOutputNode(Object calling_node)
	{
  		if(!output_node.contains(calling_node))
		{
			output_node.add(calling_node);
		}
//		else System.out.println(":-( Output node already set!!!");
	}

//------------------------------------------------------------------------------
	protected Object input_node0, input_node1;
	protected ArrayList output_node;
	protected ArrayList output_tokens;
}

##SaveTo ReteNodeCondition.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteNodeCondition.java            ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================

import java.util.*;

//==============================================================================
// ReteL Conditional node type Rule. Conditional node of network.
public class ReteNodeCondition extends ReteNode
{
	private boolean hold = true; //hold prevents sending tokens further when BC is used.

	public void SetTransparent()
	{
		if(hold)
		{
			hold = false;
			int kk = output_tokens.size();
			int ii = output_node.size();
			for(int k=0; k<kk; k++)
				for(int i=0; i<ii; i++)
					((ReteNode)output_node.get(i)).InputChange(this, (ReteToken)output_tokens.get(k));
		}
	}

	public void InputCondition(ReteToken input)
	{
		output_tokens.add(input);
		/*DEBUG*/System.out.println("In Condition " + output_tokens.size());
		
		if(!hold) for(int i=0; i<output_node.size(); i++)
			((ReteNode)output_node.get(i)).InputChange(this, input);
	}

	public void InputChange(Object calling_node, ReteToken input)
	{
		return;
	}

	public int GetToken()
	{
		return output_tokens.size();
	}

	public ReteToken GetToken(int index)
	{
		return (ReteToken)output_tokens.get(index);
	}

	public void RemoveObsoleteTokens(Object modified_object)
	{
		boolean r = false;

		for(int j=output_tokens.size()-1; j>=0; j--)
		{
			ReteToken token = (ReteToken)output_tokens.get(j);
			if(token.IsTokenObsolate(modified_object))
			{
				output_tokens.remove(j); r = true;
			}
		}
		if(r) for(int i=output_node.size()-1; i>=0; i--)
			((ReteNode)output_node.get(i)).RemoveObsoleteTokens(modified_object);
	}
}

##SaveTo ReteNodeAND.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteNodeAND.java                  ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================
import java.util.*;

//==============================================================================
// ReteL node type AND
public class ReteNodeAND extends ReteNode
{
	public void InputChange(Object calling_node, ReteToken input)
	{
		/*DEBUG*/System.out.println("In AND>>>");

		if(input_node0 == calling_node)
		{
			int t = ((ReteNode)input_node1).GetToken();

			for(int i = 0; i < t; i++)
			{
				ReteToken token = ReteToken.Join(input, ((ReteNode)input_node1).GetToken(i));
//				ReteToken.TokenPrint(input);
//				ReteToken.TokenPrint(((ReteNode)input_node1).GetToken(i));
//				ReteToken.TokenPrint(token);
				if(token!=null)
				{
					output_tokens.add(token);
					/*DEBUG*/System.out.println("In AND+0+ " + output_tokens.size());
					for(int j=0; j<output_node.size(); j++)
						((ReteNode)output_node.get(j)).InputChange(this, token);
				}
			}
		}
		else if(input_node1 == calling_node)
		{
			int t = ((ReteNode)input_node0).GetToken();
			for(int i = 0; i < t; i++)
			{
				ReteToken token = ReteToken.Join(input, ((ReteNode)input_node0).GetToken(i));
//				ReteToken.TokenPrint(input);
//				ReteToken.TokenPrint(((ReteNode)input_node0).GetToken(i));
//				ReteToken.TokenPrint(token);
				if(token!=null)
				{
					output_tokens.add(token);
				  /*DEBUG*/System.out.println("In AND+1+ " + output_tokens.size());
					for(int j=0; j<output_node.size(); j++)
						((ReteNode)output_node.get(j)).InputChange(this, token);
				}
			}
		}
		else
		{
			/*DEBUG*/System.out.println(":-( Network connection error!!!");
			return;
		}
	}

	public int GetToken()
	{
		return output_tokens.size();
	}

	public ReteToken GetToken(int index)
	{
		return (ReteToken)output_tokens.get(index);
	}

	public void RemoveObsoleteTokens(Object modified_object)
	{
		boolean r = false;

		for(int j=output_tokens.size()-1; j>=0; j--)
		{
			ReteToken token = (ReteToken)output_tokens.get(j);
			if(token.IsTokenObsolate(modified_object))
			{
				output_tokens.remove(j); r = true;
			}
		}
		if(r) for(int i=output_node.size()-1; i>=0; i--)
			((ReteNode)output_node.get(i)).RemoveObsoleteTokens(modified_object);
	}
}

##SaveTo ReteNodeOR.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteNodeOR.java                   ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================
import java.util.*;
//==============================================================================
// ReteL node type OR
public class ReteNodeOR extends ReteNode
{
	int tokens_in_node0, tokens_in_node1;
	public void InputChange(Object calling_node, ReteToken input)
	{
		/*DEBUG*/System.out.println("In OR>>>");
		for(int i=0; i<output_node.size(); i++)
			((ReteNode)output_node.get(i)).InputChange(this, input);
	}

	public int GetToken()
	{
	    tokens_in_node0 = ((ReteNode)input_node0).GetToken();
		tokens_in_node1 = ((ReteNode)input_node1).GetToken();
		return tokens_in_node0 + tokens_in_node1;
	}

	public ReteToken GetToken(int index)
	{
		if(index >= 0 && index < tokens_in_node0)
			return ((ReteNode)input_node0).GetToken(index);
		else
			return ((ReteNode)input_node1).GetToken(index - tokens_in_node0);
	}

	public void RemoveObsoleteTokens(Object modified_object)
	{
		for(int i=0; i<output_node.size(); i++)
			((ReteNode)output_node.get(i)).RemoveObsoleteTokens(modified_object);
	}
}

##SaveTo ReteNodeFinal.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteNodeFinal.java                ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================
import java.util.*;

//==============================================================================
// ReteL node type Rule. Final node of network.
public class ReteNodeFinal extends ReteNode
{
  private int node_merit;
  private int objc_merit;

  ReteNodeFinal(int i, int o)
  {
    node_merit = i;
    objc_merit = o;
  }

	public void InputChange(Object calling_node, ReteToken input)
	{
		if(input_node0 == calling_node)
		{
			if(input.Evaluate())
      {
        /*DEBUG*/System.out.println("Rule's fired+++");

        input.node_merit = node_merit;
        input.node_meats = input.timestamps[objc_merit];
        
        int ii = 0;
        for(int i = 0; i < input.objectsno; i++)
          if(ii < input.timestamps[i] && input.object[i] != null) ii = input.timestamps[i];
        input.node_lexts = ii;        
				ReteConflictSet.FireRule(input);
      }
			/*DEBUG*/else System.out.println("Rule's not fired");
		}
		else
		{
			/*DEBUG*/System.out.println(":-( Network connection error!!!");
			return;
		}
    /*DEBUG*/System.out.println("Node merit: " + node_merit + ", token added,   tokens firing the node: " + ((ReteNode)calling_node).GetToken());
	}

	public int GetToken()
	{
	    return ((ReteNode)input_node0).GetToken();
	}

	public ReteToken GetToken(int index)
	{
		return ((ReteNode)input_node0).GetToken(index);
	}

	public void RemoveObsoleteTokens(Object modified_object)
	{
    //System.out.println("Node merit: " + node_merit + ", token removed, tokens firing the node: " + ((ReteNode)input_node0).GetToken());
		//System.out.println("Token removed");
		//System.out.println("No. of tokens firing the node: " + ((ReteNode)input_node0).GetToken());
	}
}

##SaveTo ReteConflictSet.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteConflictSet.java              ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================
import java.util.*;

//==============================================================================
// ReteL node type Rule. Final node of network.
public class ReteConflictSet
{
	private static boolean mode = true; // true - FC, false - BC
  private static ArrayList token_list = new ArrayList();
  private static ArrayList token__list[];
  //private static ArrayList node_list = new ArrayList();

	public static void FireRule(ReteToken token)
	{
    if(mode) // forward chaining
		{
			if(!token_list.contains(token)) token_list.add(token);
		}
		else // backward chaining
		{
			int index = -token.node_merit-1;
			if(!token__list[index].contains(token))	token__list[index].add(token);
		}
		
		
    /*DEBUG*/for(int i = 0; i < token_list.size(); i++) System.out.println("###+ " + token_list.get(i)+ " node:" + ((ReteToken)token_list.get(i)).node_merit);
    /*DEBUG*/if(token_list.size() <= 0) System.out.println("###- " + "no tokens");
	}

	public static void BackwardMode(int rules)
	{
		mode = false;
		token_list = null;
		token__list = new ArrayList[rules];
		for(int i = 0; i < rules; i++)
		{
			token__list[i] = new ArrayList();
		}
	}

	public static void ForwardMode()
	{
		mode = true;	
		token_list = new ArrayList();
		token__list = null;
	}

	public static ArrayList GetFiredOfMerit(int merit)
	{
		int index = -merit-1;
		ArrayList al = token__list[index];
		token__list[index] = new ArrayList();
		return al;
	}

  public static String TextList()
  {
    StringBuffer sb = new StringBuffer();
    sb.append("\tConflict set:\n");
    for(int i = 0; i < token_list.size(); i++) sb.append("\t\t" + token_list.get(i)+ " node:" + ((ReteToken)token_list.get(i)).node_merit + "\n");
    return sb.toString();
  }

	public static void UnFireRule(Object modified_object)
	{
    for(int j=token_list.size()-1; j>=0; j--)
		{
			ReteToken token = (ReteToken)token_list.get(j);
			if(token.IsTokenObsolate(token_list))
			{
				token_list.remove(j);

        /*DEBUG*/for(int i = 0; i < token_list.size(); i++) System.out.println("###- " + token_list.get(i)+ " node:" + ((ReteToken)token_list.get(i)).node_merit);
        /*DEBUG*/if(token_list.size() <= 0) System.out.println("###- " + "no tokens");
			}
		}
	}

	public static ReteToken GetFiredToken(int crm)
	{
    int i = token_list.size();
    int best_node_lexts = 0;
    int best_node_meats = 0;
    int best_node_merit = Integer.MAX_VALUE;
    ReteToken best_token = null;

// The last
/*
    return (ReteToken) token_list.get(i-1);
*/
		if(i <= 0) return null;

		if(crm == 0)
		{
		// First available
			return (ReteToken)token_list.get(0);
		}
		else if(crm < 0)
		{
		// BC: crm depicts rule by it's merit value
		// this option not used really. GetFiredOfMerit() used instead.
			for(int j=i-1; j>=0; j--)
			{
        ReteToken token = (ReteToken)token_list.get(j);
				if(crm == token.node_merit) return token;
		  }
			return null;
		}
		else if(crm == 1)
    {
    // Lex: crm == 1
      for(int j=i-1; j>=0; j--)
		  {
        ReteToken token = (ReteToken)token_list.get(j);

        if(token.node_lexts > best_node_lexts)
        {
          best_node_lexts = token.node_lexts;
          best_node_merit = token.node_merit;
          best_token = token;
        }
        else if(token.node_lexts == best_node_lexts)
        {
          if(token.node_merit > best_node_merit) // Merit is negative value
          {
            best_node_merit = token.node_merit;
            best_token = token;
          }
        }
		  }
    }
    else
    {
    // MEA:  crm == 2
      for(int j=i-1; j>=0; j--)
		  {
        ReteToken token = (ReteToken)token_list.get(j);

        if(token.node_meats > best_node_meats)
        {
          best_node_meats = token.node_meats;
          best_node_lexts = token.node_lexts;
          best_node_merit = token.node_merit;
          best_token = token;
        }
        else if(token.node_meats == best_node_meats)
        {
          if(token.node_lexts > best_node_lexts)
          {
            best_node_lexts = token.node_lexts;
            best_node_merit = token.node_merit;
            best_token = token;
          }
          else if(token.node_lexts == best_node_lexts)
          {
            if(token.node_merit > best_node_merit) // Merit is negative value
            {
              best_node_merit = token.node_merit;
              best_token = token;
            }
          }
		    }
      }
    }
    return best_token;
	}

 	public static void RemoveFiredToken(ReteToken token)
	{
    if(token == null) return;
    int i = token_list.indexOf(token);
    if(i>=0) token_list.remove(i);

    //for( i = 0; i < token_list.size(); i++) System.out.println("###- " + token_list.get(i)+ " node:" + ((ReteToken)token_list.get(i)).node_merit);
    //if(token_list.size() <= 0) System.out.println("###- " + "no tokens");

	}

 	public static void RemoveTokensFromFiredRule(ReteToken token)
	{
    int token_merit;

    if(token == null) return;
    int i = token_list.indexOf(token);

    if(i>=0)
    {
      token_merit = token.node_merit;
      token_list.remove(i);

      for(int j=token_list.size()-1; j>=0; j--)
	  	{
        ReteToken tokn = (ReteToken)token_list.get(j);
        if(tokn.node_merit == token_merit) token_list.remove(j);
		  }
    }

    //for( i = 0; i < token_list.size(); i++) System.out.println("###--- " + token_list.get(i)+ " node:" + ((ReteToken)token_list.get(i)).node_merit);
    //if(token_list.size() <= 0) System.out.println("###--- " + "no tokens");
	}

 	public static void RemoveTokensWithObsoleteObjects(Object obj)
	{
    if(obj == null) return;
    
		if(mode)
    for(int j=token_list.size()-1; j>=0; j--)
	  {
      ReteToken t = (ReteToken)token_list.get(j);
      if(t.IsTokenObsolate(obj)) token_list.remove(j);
		}
		else
    for(int j=token__list.length-1; j>=0; j--)
		{
			ArrayList al = (ArrayList)token__list[j];
			for(int i=al.size()-1; i>=0; i--)
			{
				ReteToken t = (ReteToken)al.get(i);
				if(t.IsTokenObsolate(obj)) al.remove(i);
			}
		}
	}
}


##SaveTo ReteToken.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteToken.java                    ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================
import ReteObjects.*;

public class ReteToken
{
   public int node_merit = 0; // rule importance according to no. of conditions and rule position
   public int node_meats = 0; // rule importance according to time stamp of object in first condition
   public int node_lexts = 0; // rule importance according to highest time stamp

##WriteTokenArrays
##WriteTokenEvaluateFunction

    public static ReteToken Join(ReteToken t1, ReteToken t2)
    {
        boolean evaluate = false;
        ReteToken token = new ReteToken();

				for(int i = 0; i < objectsno; i++)
        {
          if(t1.object[i] == t2.object[i]) {token.object[i] = t1.object[i]; token.timestamps[i] = t1.timestamps[i];}
          else if(t1.object[i] == null) {token.object[i] = t2.object[i]; token.timestamps[i] = t2.timestamps[i];}
          else if(t2.object[i] == null) {token.object[i] = t1.object[i]; token.timestamps[i] = t1.timestamps[i];}
            else {token = null; return null;};
        }

        for(int i = 0; i < variablesno; i++)
        {
			if(t1.typeofvariable[i] == 0 && t2.typeofvariable[i] == 0)
			{
				token.typeofvariable[i] = 0;
			}

      
      
      else if(t1.typeofvariable[i] == t2.typeofvariable[i])
			{
			
        token.typeofvariable[i] = t1.typeofvariable[i];

        if(t1.variable[i] == null && t2.variable[i] == null) token.variable[i] = null;
        else if (t1.variable[i] == null || t2.variable[i] == null) {token = null; return null;};
        if( ((Comparable)(t1.variable[i])).compareTo(t2.variable[i]) == 0 )
   				token.variable[i] = t1.variable[i];
	  		else {token = null; return null;};

			}

            else if(t1.typeofvariable[i] == 0)
			{
				token.typeofvariable[i] = t2.typeofvariable[i];
				token.variable[i] = t2.variable[i];
			}
            else if(t2.typeofvariable[i] == 0)
			{
				token.typeofvariable[i] = t1.typeofvariable[i];
				token.variable[i] = t1.variable[i];
			}
			else {token = null; return null;};

			/*
            if(t1.variable[i] == t2.variable[i]) token.variable[i] = t1.variable[i];
            else if(Double.isNaN(t1.variable[i])) token.variable[i] = t2.variable[i];
            else if(Double.isNaN(t2.variable[i])) token.variable[i] = t1.variable[i];
            else {token = null; return null;};*/
        }

        for(int i = 0; i < checksno; i++)
        {
            if(t1.check[i] == 0 && t2.check[i] == 0) token.check[i] = 0;
            else if(t1.check[i] == 2 || t2.check[i] == 2) token.check[i] = 2;
            else {token.check[i] = 1; evaluate = true;};
        }

        if(evaluate)
        {
            if(Evaluate(token)) return token;
            token = null;
			return null;
        }
        else return token;
    }

	Object[] object = new Object[objectsno];
	int[] timestamps = new int[objectsno];
	//	double[] variable = new double[variablesno];
	Object[] variable = new Object[variablesno];
	int[] typeofvariable = new int[variablesno];
    int[] check = new int[checksno];

//Function used to check if object should be removed
	public boolean IsTokenObsolate(Object modified_object)
    {
        for(int i = 0; i < objectsno; i++)
            if(modified_object == object[i]) return true;
		return false;
    }

// Returns false if there are unevaluated or false checks in token
// Used by rule node
	public boolean Evaluate()
	{
		for(int i = 0; i < checksno; i++)
			if(check[i] == 1 || check[i] == 3) return false;
		return true;
	}

// Clears token
// Used by conditional node
    void ClearToken()
    {
        for(int i = 0; i < objectsno; i++) object[i] = null;
        for(int i = 0; i < variablesno; i++) variable[i] = null;
// 0 - no variable defined;
// 1 - String
// 2 - Integer
// 3 - Double
		for(int i = 0; i < variablesno; i++) typeofvariable[i] = 0;

// 0 - no check used;
// 1 - check used, not evaluated
// 2 - check used, evaluated as true
// 3 - check used, evaluated as false (not possible in network)
        for(int i = 0; i < checksno; i++) check[i] = 0;
    }
};

##SaveTo ReteNetwork.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteNetwork.java                  ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================

import java.util.*;
import ReteObjects.*;
import java.io.*;
//import WorkingMemory.*;
//import WMServer.*;
import MemoryServer.*;

import org.omg.CORBA.Any;
import org.omg.CORBA.ORB;
import org.omg.CORBA.OBJ_ADAPTER;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextHelper;
import org.omg.CosNaming.NameComponent;
import org.omg.PortableServer.POA;


//import org.omg.CORBA.ORB;
//import org.omg.CORBA.Object;
//import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CORBA.Policy;
import org.omg.PortableServer.Servant;
import org.omg.PortableServer.*;
//import org.omg.PortableServer.POA;


public class ReteNetwork
{
  private ArrayList ListOfObjects = new ArrayList();
	private ArrayList ListOfNames = new ArrayList();

  private ReteExecute executions;
  private int time_stamp = 0;
  private WMGetSetObject wmserverinterface = null;
  private org.omg.CORBA.Any anyholder;

  private Expert expert = null;
  int crm = 0;
  public boolean stop = false;

##WriteNetworkNodes

//	int timer = 0;
	public static void main(String args[]) throws NoSuchFieldException, IllegalAccessException, IOException, org.omg.CORBA.TypeCodePackage.BadKind
	{
		ReteNetwork rn= new ReteNetwork();
    
		rn.CreateNetwork();
    rn.ConnectMemory(args);
    rn.StartInferencing();
	}

  public static ReteNetwork WinMain(Expert expert, WMGetSetObject memimpl, Any any) throws NoSuchFieldException, IllegalAccessException, IOException, org.omg.CORBA.TypeCodePackage.BadKind
	{
		ReteNetwork rn= new ReteNetwork();
    rn.expert = expert;
    rn.wmserverinterface = memimpl;
    rn.crm = expert.crm;

    rn.CreateNetwork();
	  rn.anyholder = any;
    rn.StartInferencing();
    return rn;
	}

  public void SetAllTransparent()
	{
##WriteSetTransparent
	}
	
  public void ConnectMemory(String args[]) throws org.omg.CORBA.TypeCodePackage.BadKind
  {
    try
    {
      // create and initialize the ORB
      ORB orb = ORB.init(args, null);

      anyholder = orb.create_any();

      // get the root naming context
      org.omg.CORBA.Object objRef = 
        orb.resolve_initial_references("NameService");

      // Use NamingContextExt instead of NamingContext. This is 
      // part of the Interoperable Naming Service.  
      NamingContextExt ncRef = 
        NamingContextExtHelper.narrow(objRef);
 
      // resolve the Object Reference in Naming
      String name = "WMGetSetObject";
      wmserverinterface = WMGetSetObjectHelper.narrow(ncRef.resolve_str(name));

      org.omg.CORBA.StringHolder on = new org.omg.CORBA.StringHolder();
		  on.value = "... --- ...";

      try{wmserverinterface.WMGetItem(0, on);}
      catch(Throwable e){wmserverinterface = null;}

//      System.out.println("ConnectMemory wmserverinterface= " + wmserverinterface);
/*
      ORB orb = ORB.init(args, null);
      org.omg.CORBA.Object obj = orb.string_to_object("corbaname::localhost:2900#AddServer");
      anyholder = orb.create_any();
      wmserverinterface = WMGetSetObjectHelper.narrow(obj);
*/
    } 
    catch ( Exception e ) 
    {
//       System.err.println( "Exception connecting to memory server..." + e );
//       e.printStackTrace( );
    }
  }

  public String TextList()
  {
    StringBuffer sb = new StringBuffer();
    sb.append("\tObjects list:\n");
    for(int i = 0; i < ListOfObjects.size(); i++) sb.append("\t\t" + ListOfObjects.get(i) + " : " + ListOfNames.get(i) + "\n");
    return sb.toString();
  }

// Returns 1, 2 or 3 if variable is of type 
// String, Integer or Double respectively; 0 otherwise.
	public static int TypeOfObject(Object x)
	{
		String xx = x.getClass().getName();
		if(xx.compareTo("java.lang.String")==0) return 1;
		if(xx.compareTo("java.lang.Integer")==0) return 2;
		if(xx.compareTo("java.lang.Double")==0) return 3;
		return 0;
	}
	public static int TypeOfObject(String x){return 1;}
	public static int TypeOfObject(Integer x){return 2;}
	public static int TypeOfObject(Double x){return 3;}
	public static int TypeOfObject(int x){return 2;}
	public static int TypeOfObject(double x){return 3;}

	public static String ReturnClass(String x){return x;}
	public static Double ReturnClass(double x){return new Double(x);}
	public static Integer ReturnClass(int x){return new Integer(x);}
	public static Double ReturnClass(Double x){return x;}
	public static Integer ReturnClass(Integer x){return x;}


	public boolean FeedNetwork(Object obj, int time_stamp)
	{
		ReteToken token;
##WriteFeedingSlots
		return false;
	}

	public void UnFeedNetwork(Object obj)
	{
    ReteConflictSet.RemoveTokensWithObsoleteObjects(obj);

##WriteUnFeedingSlots
	}

	public int CreateNetwork()
	{
##WriteNetworkConnections
		return 0;
	}

	public void BackwardChainingSeq(ReteExecute executions)throws NoSuchFieldException, IllegalAccessException, IOException, org.omg.CORBA.TypeCodePackage.BadKind
	{
##WriteBackwardChaining
	}

	public void StartInferencing() throws NoSuchFieldException, IllegalAccessException, IOException, org.omg.CORBA.TypeCodePackage.BadKind
  {
    ReteToken token;
    executions = new ReteExecute(this, expert); 

		if(crm == 3) 
		{
##WriteStarter
			BackwardChainingSeq(executions);
		}
		else
		{
			SetAllTransparent();
      ReteConflictSet.ForwardMode();
##WriteStarter
			do
			{
//				if(wmserverinterface!=null)	LoadObjectsFromWM();
				
				token = ReteConflictSet.GetFiredToken(crm);
				if(token != null)
				{
					ReteConflictSet.RemoveTokensFromFiredRule(token);
					executions.ExecuteRule(token);
					token = null;
				}
				else if(wmserverinterface!=null) LoadObjectsFromWM(true);
			}
	//    while(true);
	//    while((token != null) && (!stop));
			while(!stop);
		}
  }

  public void MemSetObject(Object obj, String name) 
  throws org.omg.CORBA.TypeCodePackage.BadKind, java.lang.IllegalAccessException
	{
    if(wmserverinterface==null)
    {
      time_stamp ++;
      if(name == null && obj != null)
      {
        UnFeedNetwork(obj);
        FeedNetwork(obj, time_stamp);
        return;
		  }
      
      int i = ListOfNames.indexOf(name);
		  if(i<0)
		  {
			  ListOfObjects.add(obj);
			  ListOfNames.add(name);
        FeedNetwork(obj, time_stamp);
		  }
		  else 
		  {
        if(obj == null)
        {
          Object oo = ListOfObjects.get(i);
          if(oo != null)
          {
            UnFeedNetwork(oo);
            //ReteConflictSet.RemoveTokensWithObsoleteObjects(oo);
            ListOfObjects.set(i, null);
          }
        }
        else
        {
          Object oo = ListOfObjects.get(i);
          UnFeedNetwork(oo);
          //ReteConflictSet.RemoveTokensWithObsoleteObjects(oo);
	  		  ListOfObjects.set(i, obj);
          FeedNetwork(obj, time_stamp);
        }
		  }
      /*DEBUG*/for( i = 0; i < ListOfNames.size(); i++) System.out.println("***+" + ListOfObjects.get(i) + " : " + ListOfNames.get(i));
    }
    else
    {
      if(name == null)
      {
        if(obj == null) return;
        int i = ListOfObjects.indexOf(obj);
  		  if(i<0) return;
  		  name = (String)ListOfNames.get(i);
      }

      if(obj == null)
      {
        wmserverinterface.WMDeleteObject(name);
				LoadObjectsFromWM(true);
      }
      else
      {
          Class objclass = obj.getClass();
          String classname = objclass.getName();
// Setting up null strings in object        
          java.lang.reflect.Field[] fields = objclass.getFields();
          for(int f = 0; f < fields.length; f++)
          {
            if(fields[f].getType() == classname.getClass())
              if(fields[f].get(obj) == null) fields[f].set(obj, "");
          }

//      (else) if(obj.getClass().getName().compareTo("ReteObjects.classname")==0) RzeczHelper.insert(anyholder, (classname)obj);

        boolean set = true;
##WriteConvertToAny
        else set = false;
        if(set)
				{
					wmserverinterface.WMSetObject(anyholder, name);
					LoadObjectsFromWM(true);
				}
      }
    }
  }
/*
  public Object MemGetObject(String name)
	{
		int i = ListOfNames.indexOf(name);
		if(i>=0) return ListOfObjects.get(i);
    else return null;
	}
*/


  public void LoadObjectsFromWM(boolean wait) throws org.omg.CORBA.TypeCodePackage.BadKind
  {
//    if(wmserverinterface == null) return;
//    expert.Print("+");
		if(wait) wmserverinterface.WMWaitForChange(time_stamp);

		org.omg.CORBA.IntHolder ti = new org.omg.CORBA.IntHolder();
			ti.value = 0;
		org.omg.CORBA.StringHolder on = new org.omg.CORBA.StringHolder();
 			on.value = "";
		org.omg.CORBA.AnyHolder ah = new org.omg.CORBA.AnyHolder();

		try
		{
      int tmax = -1;
      do
      {
        Object obj = null;

/*
        do{
          wmserverinterface.WMGetObject(time_stamp, ti, on, ah);
          if(stop) return;
        }while(time_stamp>=ti.value);
*/

        wmserverinterface.WMGetObject(time_stamp, ti, on, ah);

        if(ti.value<0) {stop = true; return;}

        if(tmax < 0) tmax = ti.value;

        if(ah.value == null || ah.value.type().kind() == org.omg.CORBA.TCKind.tk_null)
        {
          if(on.value != null)
          {
            int i = ListOfNames.indexOf(on.value);
		        if(i>=0)
            {
              UnFeedNetwork(ListOfObjects.get(i));
              ListOfObjects.set(i, null);
            }
          }
        }
        else
        {

##WriteConvertFromAny

          if(on.value != null)
          {
            int i = ListOfNames.indexOf(on.value);
		        if(i>=0)
            {
              Object oo = ListOfObjects.get(i);
              if(oo != null) UnFeedNetwork(oo);
              ListOfObjects.set(i, obj);
            }
            else
            {
		  	      ListOfObjects.add(obj);
    		      ListOfNames.add(on.value);
            }
            FeedNetwork(obj, time_stamp+1);
          }
        }
		    time_stamp++;
				if(ti.value < tmax) break;
      }while(time_stamp < tmax);
    }
		catch(Throwable e){}
    Thread.yield();
  }
}

##SaveTo ReteExecute.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  ReteExecute.java                  ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================

import java.util.*;
import ReteObjects.*;
import java.lang.*;
import java.lang.reflect.*;
import java.io.*;

public class ReteExecute
{
  private Object oo;
  private Field ff;
  private ReteNetwork network;
  private BufferedReader ois;
  private javax.swing.JTextField jtext;
  private Expert expert = null;

  public ReteExecute(ReteNetwork n)
  {
    network = n;
  };

  public ReteExecute(ReteNetwork n, Expert e)
  {
    network = n;
    expert = e;
  };

  private void Print(String s)
  {
    if(expert != null) expert.Print(s);
    else System.out.print(s);
  }

  private String ReadLine() throws IOException
  {
    if(expert != null) return expert.Read();

    ois = new BufferedReader(new InputStreamReader(System.in));
    return ois.readLine();
  }

  private void Display(String filename) throws IOException
  {
    if(expert != null) expert.Display(filename);
    else Runtime.getRuntime().exec("cmd /c \""+ filename + "\"");
  }

  public static void SetField(Object oo, Field ff, double dd) throws IllegalArgumentException, IllegalAccessException
  {
    if(ff.getType().getName().compareTo("double")==0)
    {
      ff.setDouble(oo, dd);
    }
    else if(ff.getType().getName().compareTo("int")==0)
    {
      ff.setInt(oo, (int)dd);
    }
    else if(ff.getType().getName().compareTo("java.lang.String")==0)
    {
      ff.set(oo, (new Double(dd)).toString());
    }
  }
  public static void SetField(Object oo, Field ff, int ii) throws IllegalArgumentException, IllegalAccessException
  {
    if(ff.getType().getName().compareTo("int")==0)
    {
      ff.setInt(oo, ii);
    }
    else if(ff.getType().getName().compareTo("double")==0)
    {
      ff.setDouble(oo, (double)ii);
    }
    else if(ff.getType().getName().compareTo("java.lang.String")==0)
    {
      ff.set(oo, (new Integer(ii)).toString());
    }
  }
  public static void SetField(Object oo, Field ff, String ss) throws IllegalArgumentException, IllegalAccessException
  {
    if(ff.getType().getName().compareTo("java.lang.String")==0)
    {
      ff.set(oo, ss);
    }
  }

##WriteExecutions
  
  public void ExecuteRule(ReteToken token) throws NoSuchFieldException, IllegalAccessException, IOException, org.omg.CORBA.TypeCodePackage.BadKind
  {
    switch(token.node_merit)
    {
##WriteDispatchExecution
    }
  }
}

##SaveTo MemoryServer.idl
module MemoryServer 
{
   interface WMGetSetObject 
   {
		void WMSetObject(in any obj, in string name);
		void WMDeleteObject(in string name);
		void WMGetObject(in long tin, out long tmax, out string on, out any obj);
    void WMWaitForChange(in long ti);
		void WMGetItem(in long index, out string name);
   };
};

##SaveTo Expert.java
//==============================================================================
//==============================================================================
//==                                    ===****=====**=====**=====****==========
//==  Expert.java                       ===*===*====*=*===*=*====*====*=========
//==                                    ===*===*====*==*=*==*=====**============
//==  (C) 2002 by Piotr M. Szczypinski  ===****=====*===*===*=======**==========
//==  NIST - Gaithersburg               ===*========*=======*====*====*=========
//==                                    ===*========*=======*=====****==========
//==============================================================================
//==============================================================================
import MemoryServer.*;
import ReteObjects.*;

import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;

/**
 *
 * @author  pms
 */
public class Expert extends javax.swing.JFrame {
    private WMGetSetObject impl=null;
    private ORB orb;
    private Any anyholder;
    private boolean reading = false;
    public ReteNetwork rn;

    public String[] argums = {};
    public int crm = 0; // Conflict resolution method

    private synchronized void SetReading(boolean r)
    {
      reading = r;
      notifyAll();
    }

    public void Print(String string)
    {
        jTextArea1.append(string);
    }
    public synchronized String Read()
    {
        String ret;
        reading = true;
        jTextField1.setEditable(true);
        jTextField1.setText("");
        jTextField1.requestFocus();
        jTextField1.setCaretPosition(0);
        while(reading == true) 
        {  
          try{wait();}
          catch(Throwable e){Thread.yield();}
        }
        jTextField1.setEditable(false);
        ret = jTextField1.getText();

        Print(ret + "\r\n");
        return ret;
    }
    public void Display(String filename)
    {
        jLabel1.setIcon(new javax.swing.ImageIcon (filename));
    }
 
    /** Creates new form Expert */
    public Expert() {
        initComponents();
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        jSplitPane1 = new javax.swing.JSplitPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jTextField2 = new javax.swing.JTextField();

        setTitle("Expert");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        jScrollPane1.setBackground(new java.awt.Color(204, 204, 204));
        jLabel1.setBackground(new java.awt.Color(204, 204, 204));
        jScrollPane1.setViewportView(jLabel1);

        jSplitPane1.setLeftComponent(jScrollPane1);

        jPanel1.setLayout(new java.awt.BorderLayout());

        jTextField1.setEditable(false);
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField1KeyPressed(evt);
            }
        });

        jPanel1.add(jTextField1, java.awt.BorderLayout.SOUTH);

        jScrollPane2.setBorder(null);
        jScrollPane2.setAutoscrolls(true);
        jTextArea1.setBackground(new java.awt.Color(255, 255, 204));
        jTextArea1.setEditable(false);
        jTextArea1.setLineWrap(true);
        jTextArea1.setTabSize(2);
        jTextArea1.setWrapStyleWord(true);
        jScrollPane2.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jSplitPane1.setRightComponent(jPanel1);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        jTextField2.setBackground(new java.awt.Color(204, 204, 204));
        jTextField2.setFont(new java.awt.Font("Dialog", 1, 10));
        jTextField2.setBorder(null);
        jTextField2.setEditable(false);
        getContentPane().add(jTextField2, java.awt.BorderLayout.SOUTH);
        pack();
    }//GEN-END:initComponents

    private void jTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyPressed
        // Add your handling code here:
        if(evt.getKeyCode()== evt.VK_ENTER) SetReading(false);//reading = false;
/*        
        {
            String name = jTextField1.getText();
            String[] namesplit = name.split(" ");
            
//            jLabel1.setIcon(new javax.swing.ImageIcon (jTextField1.getText()));
            jTextArea1.append("    " + name + "\n");

            mechanic mmm = new mechanic();
            mmm.first_name = namesplit[1];
            mechanicHelper.insert(anyholder, mmm);
            
            impl.WMSetObject(anyholder, namesplit[0]);
            
            jTextField1.setText("");
        }
 */
    }//GEN-LAST:event_jTextField1KeyPressed

    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        if(rn != null)
        {
          rn.stop = true;
          Thread.yield();
        }
        System.exit(0);
    }//GEN-LAST:event_exitForm

    private void ConnectServer()
    {
      try{
          // create and initialize the ORB
          jTextField2.setText("Initializing ORB...");

          orb = ORB.init(argums, null);
          anyholder = orb.create_any();

//jTextArea1.append("Initializing ORB with:" + argums.toString() +"\n");

          // get the root naming context
          org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");

          // Use NamingContextExt instead of NamingContext. This is
          // part of the Interoperable Naming Service.
          NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

          jTextField2.setText("Connecting to memory...");

          // resolve the Object Reference in Naming
          String name = "WMGetSetObject";
          impl = WMGetSetObjectHelper.narrow(ncRef.resolve_str(name));

          //System.out.println("Handle obtained on server object: " + impl);
//          jTextArea1.append("Handle obtained on server object: " + impl +"\n");
//          if(impl != null)
//            (new CheckMemoryThread(impl, this)).start();

      }
      catch(Throwable e)
      {
        impl = null;
        jTextArea1.append("Exception in WMServer Startup " + e +"\n");
                //System.err.println(e.getMessage());
                //e.printStackTrace();

      }
    }

    private void Inference()
    {
      try{
        (new CheckMemoryThread(impl, this)).start();
      }
      catch(Throwable e)
      {
//        System.err.println(e.getMessage());
//        e.printStackTrace();
      }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        Expert expert = new Expert();
        
        expert.crm = 0;
        if(args.length > 0)
        {
          if(args[0].compareToIgnoreCase("-Lex")==0) expert.crm = 1;
          else if(args[0].compareToIgnoreCase("-MEA")==0) expert.crm = 2;
          else if(args[0].compareToIgnoreCase("-BC")==0) expert.crm = 3;
        }
        if(expert.crm == 0) expert.argums = args;
        else
        {
           expert.argums = new String[args.length - 1];
           for(int ar = 0; ar < (args.length-1); ar++) expert.argums[ar] = args[ar+1];
        }

/*        
////////////////???????????????????
expert.jTextArea1.append("Main Args:\n");
for(int gg = 0; gg < args.length; gg++) expert.jTextArea1.append("#"+ args[gg] + "$");
////////////////???????????????????
expert.jTextArea1.append("\n\nMain Argums:\n");
for(int gg = 0; gg < expert.argums.length; gg++) expert.jTextArea1.append("#"+ expert.argums[gg] + "$");
*/

        expert.jTextField2.setText("Starting system...");
        expert.show();
        
        if(expert.argums.length > 0) expert.ConnectServer();
        expert.Inference();
    }

    class CheckMemoryThread extends Thread
	{
		WMGetSetObject im;
//		javax.swing.JTextArea ta;
		int time_stamp = 0;
		Expert ex;

		public CheckMemoryThread(WMGetSetObject impl, Expert exp)
		{
//			ta = txtar;
			ex = exp;
			im = impl;
		}
 		public void run()
		{
      StringBuffer sb = new StringBuffer();
      for(int ar = 0; ar < argums.length; ar++) sb.append(argums[ar] + " ");

      if(im == null) jTextField2.setText("Inferencing - transient memory");
      else jTextField2.setText("Inferencing - persistent memory: " + sb.toString());

      try 
      {
        rn = ReteNetwork.WinMain(ex, im, anyholder);
//        Print("\nInferencing stopped\n");
        jTextField2.setText("Inferencing stopped");
      } 
			catch(Throwable e)
			{
//				System.err.println(e.getMessage());
//                e.printStackTrace();
//        Print("\nInferencing stopped\n");
        jTextField2.setText("Inferencing stopped!");

			};
		}
	}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables

}
